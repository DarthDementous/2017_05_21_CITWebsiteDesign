CIT Website Assignment Submission:

CIT Number: CIT214946

Note on w3schools HTML validation:

- The game_list will come up with warnings and errors about duplicated IDs, I understand the danger behind this but 
I have handled it in a way so that it's only ever looking at one set of unique IDs at a time in my javascript file.


Additional notes:
- The compiled help manual will appear blank unless you go to Properties->Unblock.

- This website has been developed to work with Google Chrome only, please run with the latest update.

Github repository for history of development:
https://github.com/DarthDementous/2017_05_21_CITWebsiteDesign 